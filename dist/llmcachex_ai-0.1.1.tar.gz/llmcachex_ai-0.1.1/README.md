# 🚀 llmcachex-ai

pip install llmcachex-ai

**Drop-in caching + retrieval layer for LLM applications (RAG, agents, chatbots)**

Stop paying for repeated LLM calls. Automatically reuse responses using **exact + semantic caching** with zero changes to your business logic.

---

## ⚡ Installation

```bash
pip install llmcachex-ai
```

---

## ✨ Why llmcachex-ai?

Most LLM applications repeatedly call the model for:

* Slightly rephrased questions
* Agent/tool loops
* Chat history variations

👉 This leads to **higher latency + unnecessary cost**

**llmcachex-ai solves this automatically** by caching intelligently.

---

## 🔥 Features

* ⚡ Exact cache (Redis-backed)
* 🧠 Semantic cache (FAISS + embeddings)
* 🔍 Hybrid retrieval (BM25 + vector search)
* 🧬 Cross-encoder reranking
* 🤖 Agent + tool compatible
* 🧵 Memory-aware context support
* 💰 Token + cost tracking
* 🧩 Plug-and-play decorator API

---

## 🏗️ How It Works

```
User Query
   ↓
llm_cache decorator
   ├── Exact Cache (Redis)
   ├── Semantic Engine
   │     ├── FAISS (vector)
   │     ├── BM25 (lexical)
   │     └── CrossEncoder (rerank)
   └── LLM / Agent
```

---

## 🚀 Quick Start

```python
from llmcachex_ai import llm_cache, CacheConfig

@llm_cache(CacheConfig())
def ask_llm(prompt):
    return llm(prompt)

print(ask_llm("What is AI?"))      # LLM call
print(ask_llm("Explain AI"))       # Semantic cache hit
```

---

## 🤖 Agent Example

Works seamlessly with tools:

```python
@llm_cache(CacheConfig())
def agent(raw_query, full_prompt):

    if "calculate" in raw_query:
        return str(eval(raw_query.replace("calculate", "").strip()))

    if "search" in raw_query:
        return f"[TOOL SEARCH RESULT] {raw_query}"

    return llm(full_prompt)
```

---

## 🧠 Semantic Cache (Why it’s powerful)

Unlike basic caching:

```
"What is AI?"
"Explain artificial intelligence"
```

👉 Both return the **same cached response**
👉 No LLM call needed

---

## ⚙️ Configuration

```python
CacheConfig(
    enable_exact=True,
    enable_semantic=True,
    similarity_threshold=0.7,
    top_k=3,
    model_name="gpt-4o-mini",
    enable_metrics=True,
    enable_token_cost=True
)
```

---

## 📊 Metrics

```python
from llmcachex_ai import metrics

print(metrics.summary())
```

Example output:

```python
{
  "hits": 2,
  "misses": 1,
  "hit_rate": 66.67,
  "avg_llm_latency_ms": 2000,
  "avg_cache_latency_ms": 30,
  "total_cost_rupees": 0.01
}
```

---

## 📁 Project Structure

```
llm_cachex/
├── api/            # decorator layer
├── core/           # cache, metrics, memory
├── semantic/       # hybrid search + reranker
├── embedding/      # embeddings
├── index/          # FAISS index
├── similarity/     # similarity utils
├── utils/          # helpers
```

---

## 🧭 Roadmap

* [ ] Async support
* [ ] Streaming support
* [ ] Batch inference
* [ ] Multi-model caching
* [ ] Pluggable vector DBs (Chroma / Pinecone)
* [ ] Observability dashboard

---

## 🤝 Contributing

PRs welcome. Open an issue to discuss ideas.

---

## 📜 License

MIT License

---

## 👤 Author

Himanshu Singh

---

## ⭐ If this helps you

Give it a star ⭐ — it helps the project grow.
